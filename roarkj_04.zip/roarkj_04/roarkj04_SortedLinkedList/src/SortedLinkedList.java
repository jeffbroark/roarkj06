import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * File: SortedLinkedList.java
 * 
 * This program defines a sorted linked list.
 * 
 * @author Jeff Roark
 * Date_created: 05/28/2024
 * Date_last_modified: 06/01/2024
 * @version Java 21.01
 */

/**
 * A program that reads a list of numbers from the input,
 * stores them in a linked list, and sorts them in ascending order.
 */
public class SortedLinkedList {

    /**
     * The main method that runs the program.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create a LinkedList to store the integers
        List<Integer> numbers = new LinkedList<>();

        // Read integers from the input
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter numbers separated by a space and press Enter, then type 'done' and press Enter to finish:");

        // Read input until 'done' is entered
        while (scanner.hasNext()) {
            if (scanner.hasNextInt()) {
                int number = scanner.nextInt();
                numbers.add(number);
            } else {
                String input = scanner.next();
                if (input.equalsIgnoreCase("done")) {
                    break;
                } else {
                    System.out.println("Invalid input. Please enter numbers separated by a space or 'done' to end the program.");
                }
            }
        }
        scanner.close();

        // Sort the linked list
        Collections.sort(numbers);

        // Print the sorted list
        System.out.println("Sorted list: " + numbers);
    }
}
